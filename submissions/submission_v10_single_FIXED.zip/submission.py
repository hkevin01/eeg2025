"""
Single Model Submission v10 - Best CompactCNN (seed 456) - FIXED
Challenge 1: CompactResponseTimeCNN (Pearson r=0.0211 on validation)
Challenge 2: EEGNeX (from Oct 24 submission)
FIXES: Weight filename mismatch that caused v9 to fail
"""

import torch
import torch.nn as nn
from pathlib import Path


def find_weights(filename):
    """Find weights file in competition environment"""
    candidates = [
        filename,
        f"/app/input/res/{filename}",
        f"/app/input/{filename}",
        str(Path(__file__).parent / filename),
    ]
    
    for path in candidates:
        if Path(path).exists():
            return path
    
    raise FileNotFoundError(f"Cannot find {filename}")


class CompactResponseTimeCNN(nn.Module):
    """Simple 3-layer CNN - best performer (seed 456)"""
    
    def __init__(self, n_channels=129, sequence_length=200):
        super().__init__()
        
        self.features = nn.Sequential(
            nn.Conv1d(n_channels, 32, kernel_size=7, stride=2, padding=3),
            nn.BatchNorm1d(32),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            
            nn.Conv1d(32, 64, kernel_size=5, stride=2, padding=2),
            nn.BatchNorm1d(64),
            nn.ReLU(inplace=True),
            nn.Dropout(0.4),
            
            nn.Conv1d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten()
        )
        
        self.regressor = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(64, 32),
            nn.ReLU(inplace=True),
            nn.Dropout(0.4),
            nn.Linear(32, 1)
        )
    
    def forward(self, x):
        features = self.features(x)
        predictions = self.regressor(features)
        return predictions


# Import EEGNeX or similar for Challenge 2
try:
    from braindecode.models import EEGNeX
except ImportError:
    # Fallback if braindecode not available
    print("Warning: braindecode not available, using placeholder")
    class EEGNeX(nn.Module):
        def __init__(self, **kwargs):
            super().__init__()
            self.placeholder = nn.Linear(129*200, 1)
        def forward(self, x):
            return self.placeholder(x.flatten(1))


class Submission:
    """Competition submission with best single model - FIXED"""
    
    def __init__(self, SFREQ, DEVICE):
        self.SFREQ = SFREQ
        self.DEVICE = DEVICE
        self.model_c1 = None
        self.model_c2 = None
        
        print("\n" + "="*60)
        print("Single Model Submission v10 - FIXED")
        print("="*60)
    
    def get_model_challenge_1(self):
        """Challenge 1: Best CompactCNN (seed 456)"""
        if self.model_c1 is None:
            self.model_c1 = CompactResponseTimeCNN()
            
            try:
                # FIXED: Look for weights_challenge_1.pt (no _single suffix)
                weights_path = find_weights('weights_challenge_1.pt')
                weights = torch.load(weights_path,
                                   map_location=self.DEVICE,
                                   weights_only=False)
                self.model_c1.load_state_dict(weights)
                print("✅ Loaded CompactCNN weights (seed 456, r=0.0211)")
            except Exception as e:
                print(f"❌ ERROR loading C1 weights: {e}")
                print("   Using RANDOM weights - will perform poorly!")
                raise
            
            self.model_c1.to(self.DEVICE)
            self.model_c1.eval()
        
        return self.model_c1
    
    def get_model_challenge_2(self):
        """Challenge 2: EEGNeX from Oct 24 submission"""
        if self.model_c2 is None:
            self.model_c2 = EEGNeX(
                n_chans=129,
                n_times=200,
                n_outputs=1,
                sfreq=self.SFREQ
            )
            
            try:
                # FIXED: Look for weights_challenge_2.pt (no _single suffix)
                weights_path = find_weights('weights_challenge_2.pt')
                weights = torch.load(weights_path,
                                   map_location=self.DEVICE,
                                   weights_only=False)
                self.model_c2.load_state_dict(weights)
                print("✅ Loaded Challenge 2 weights (EEGNeX)")
            except Exception as e:
                print(f"❌ ERROR loading C2 weights: {e}")
                raise
            
            self.model_c2.to(self.DEVICE)
            self.model_c2.eval()
        
        return self.model_c2
    
    def __call__(self, X_test_c1, X_test_c2):
        """Make predictions on test sets"""
        with torch.no_grad():
            # Challenge 1
            if X_test_c1 is not None and len(X_test_c1) > 0:
                model_c1 = self.get_model_challenge_1()
                X_c1 = torch.tensor(X_test_c1, dtype=torch.float32, device=self.DEVICE)
                pred_c1 = model_c1(X_c1).cpu().numpy()
            else:
                pred_c1 = None
            
            # Challenge 2
            if X_test_c2 is not None and len(X_test_c2) > 0:
                model_c2 = self.get_model_challenge_2()
                X_c2 = torch.tensor(X_test_c2, dtype=torch.float32, device=self.DEVICE)
                pred_c2 = model_c2(X_c2).cpu().numpy()
            else:
                pred_c2 = None
        
        return pred_c1, pred_c2


# Test code (only runs locally)
if __name__ == "__main__":
    print("\n" + "="*60)
    print("TESTING SUBMISSION - FIXED VERSION")
    print("="*60)
    
    submission = Submission(SFREQ=100, DEVICE='cpu')
    
    # Test C1
    print("\nChallenge 1: CompactCNN (seed 456)")
    model_c1 = submission.get_model_challenge_1()
    x_c1 = torch.randn(4, 129, 200)
    with torch.no_grad():
        pred_c1 = model_c1(x_c1)
    print(f"Output shape: {pred_c1.shape}")
    print(f"Sample predictions: {pred_c1[:3].squeeze().tolist()}")
    print("✅ Challenge 1 PASS")
    
    # Test C2
    print("\nChallenge 2: EEGNeX")
    model_c2 = submission.get_model_challenge_2()
    x_c2 = torch.randn(4, 129, 200)
    with torch.no_grad():
        pred_c2 = model_c2(x_c2)
    print(f"Output shape: {pred_c2.shape}")
    print(f"Sample predictions: {pred_c2[:3].squeeze().tolist()}")
    print("✅ Challenge 2 PASS")
    
    print("\n" + "="*60)
    print("✅ ALL TESTS PASSED!")
